// 视频全屏下特殊卡、音乐卡与文章的内容视口及背景接入。
#import "DKFeedCardFit.h"
#import "DKVideoFullscreen.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <string.h>

@interface AWESpecialCardTemplateLynxViewController : UIViewController
@end
@interface AWESearchFeedArticleViewController : UIViewController
@end
@interface AWEFeedPOIDynamicCardCellViewController : UIViewController
@end
@interface DKMusicCardController : UIViewController
@end

static UIView *DKCardMusicLynxContainer(UIView *root) {
    Class containerClass = NSClassFromString(@"HunterBulletContainerView");
    for (UIView *subview in root.subviews) {
        if ([subview isKindOfClass:containerClass]) return subview;
    }
    return nil;
}

static void DKSpecialCardBackdrop(UIViewController *controller, BOOL refreshImage) {
    if (!DKVideoFullscreenOn()) return;
    UIView *root = controller.viewIfLoaded;
    UIView *host = root.superview;
    if (!host) return;
    // 约束已生效后才按实际内容底边铺背景，加载回调早于布局时保持空白。
    CGRect content = [root convertRect:root.bounds toView:host];
    CGFloat inset = DKFeedCardContainerIsFitted(root)
        ? MAX(CGRectGetMaxY(host.bounds) - CGRectGetMaxY(content), 0.0) : 0.0;
    DKFeedCardSyncBackdrop(host, inset, DKFeedCardTypeSpecial);
    if (refreshImage) DKFeedCardRequestBackdropSample(host);
}

%group DKSpecialCardFit
%hook AWESpecialCardTemplateLynxViewController
- (void)viewWillLayoutSubviews {
    if (DKVideoFullscreenOn()) {
        UIView *root = self.viewIfLoaded;
        DKFeedCardFitContainer(root, DKFeedCardInset(root.superview), DKFeedCardTypeSpecial);
    }
    %orig;
}
- (void)viewDidLayoutSubviews {
    %orig;
    DKSpecialCardBackdrop(self, NO);
}
- (void)viewDidAppear:(BOOL)animated { %orig; DKSpecialCardBackdrop(self, YES); }
- (void)viewDidDisappear:(BOOL)animated {
    %orig;
    if (DKVideoFullscreenOn()) DKFeedCardSyncBackdrop(self.viewIfLoaded.superview, 0.0, DKFeedCardTypeSpecial);
}
%end
%end

%group DKSpecialCardLoaded
%hook AWESpecialCardTemplateLynxViewController
- (void)hunterContainerDidFinishLoadWithURL:(id)url { %orig; DKSpecialCardBackdrop(self, YES); }
%end
%end

%group DKSpecialCardDisplay
%hook AWESpecialCardTemplateLynxViewController
- (void)willDisplay { %orig; DKSpecialCardBackdrop(self, YES); }
%end
%end

%group DKMusicCardFit
%hook DKMusicCardController
- (void)viewWillLayoutSubviews {
    if (DKVideoFullscreenOn()) {
        UIView *root = ((UIViewController *)self).viewIfLoaded;
        DKFeedCardFitContainer(DKCardMusicLynxContainer(root), DKFeedCardInset(root), DKFeedCardTypeMusic);
    }
    %orig;
}
%end
%end

// POI 动态卡片的 Lynx 内容容器；容器收短后 Lynx 视图不跟约束缩放，需同步 frame。
static UIView *DKPOIDynamicContainer(UIViewController *controller) {
    Class containerClass = NSClassFromString(@"AWEDynamicCardContainer");
    UIView *root = controller.viewIfLoaded;
    for (UIView *subview in root.subviews) {
        if ([subview isKindOfClass:containerClass]) return subview;
    }
    return nil;
}

static void DKPOIDynamicCardFit(UIViewController *controller) {
    if (!DKVideoFullscreenOn()) return;
    UIView *container = DKPOIDynamicContainer(controller);
    if (!container) return;
    CGFloat inset = DKFeedCardInset(container);
    DKFeedCardFitContainer(container, inset, DKFeedCardTypeSpecial);
    if (DKFeedCardContainerIsFitted(container)) {
        for (UIView *card in container.subviews) {
            if (fabs(card.bounds.size.height - container.bounds.size.height) > 0.5) {
                card.frame = CGRectMake(0, 0, container.bounds.size.width, container.bounds.size.height);
            }
        }
    }
}

static void DKArticleBackdrop(UIViewController *controller, BOOL refreshImage) {
    if (!DKVideoFullscreenOn()) return;
    UIView *root = controller.viewIfLoaded;
    DKFeedCardSyncBackdrop(root, DKFeedCardInset(root), DKFeedCardTypeArticle);
    if (refreshImage) DKFeedCardRequestBackdropSample(root);
}

%group DKPOICardFit
%hook AWEFeedPOIDynamicCardCellViewController
- (void)viewWillLayoutSubviews {
    DKPOIDynamicCardFit(self);
    %orig;
}
- (void)viewDidLayoutSubviews {
    %orig;
    DKPOIDynamicCardFit(self);
}
%end
%end

%group DKArticleFit
%hook AWESearchFeedArticleViewController
- (void)viewDidLayoutSubviews { %orig; DKArticleBackdrop(self, NO); }
%end
%end

%group DKArticleMounted
%hook AWESearchFeedArticleViewController
- (void)lynxEngineDidMount:(id)engine { %orig; DKArticleBackdrop(self, YES); }
%end
%end

%group DKArticleModel
%hook AWESearchFeedArticleViewController
- (void)updateModel:(id)model { %orig; DKArticleBackdrop(self, YES); }
%end
%end

static void DKArticleInstallHooks(void) {
    static BOOL installed;
    Class article = NSClassFromString(@"AWESearchFeedArticleViewController");
    if (installed || ![article isSubclassOfClass:UIViewController.class]) return;
    installed = YES;
    %init(DKArticleFit);
    if (class_getInstanceMethod(article, @selector(lynxEngineDidMount:))) { %init(DKArticleMounted); }
    if (class_getInstanceMethod(article, @selector(updateModel:))) { %init(DKArticleModel); }
}

// 文章正文控制器在 AWESearchFramework 里，该框架晚于插件加载；回调在加载器上下文内，只调度到主队列安装。
static void DKArticleImageAdded(const struct mach_header *header, intptr_t slide) {
    Dl_info image = {0};
    if (!dladdr(header, &image) || !image.dli_fname) return;
    const char *name = strrchr(image.dli_fname, '/');
    if (strcmp(name ? name + 1 : image.dli_fname, "AWESearchFramework") != 0) return;
    dispatch_async(dispatch_get_main_queue(), ^{ DKArticleInstallHooks(); });
}

%ctor {
    Class special = NSClassFromString(@"AWESpecialCardTemplateLynxViewController");
    if ([special isSubclassOfClass:UIViewController.class]) {
        %init(DKSpecialCardFit);
        if (class_getInstanceMethod(special, @selector(hunterContainerDidFinishLoadWithURL:))) { %init(DKSpecialCardLoaded); }
        if (class_getInstanceMethod(special, @selector(willDisplay))) { %init(DKSpecialCardDisplay); }
    }
    Class music = NSClassFromString(@"AWEMusicStreamingSwiftImpl.MusicCardViewController");
    if ([music isSubclassOfClass:UIViewController.class]) { %init(DKMusicCardFit, DKMusicCardController = music); }
    Class poiCard = NSClassFromString(@"AWEFeedPOIDynamicCardCellViewController");
    if ([poiCard isSubclassOfClass:UIViewController.class]) { %init(DKPOICardFit); }
    DKArticleInstallHooks();
    _dyld_register_func_for_add_image(DKArticleImageAdded);
    DKVideoFullscreenRegisterRestore(DKFeedCardRestore);
}
